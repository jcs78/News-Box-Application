DROP TABLE IF EXISTS `articleCommentsTable`;

DROP TABLE IF EXISTS `articleTable`;

DROP TABLE IF EXISTS `forumPosts`;

DROP TABLE IF EXISTS `forumReplyTable`;

DROP TABLE IF EXISTS `newsBoxUsers`;
