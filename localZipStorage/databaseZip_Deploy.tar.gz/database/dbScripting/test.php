#!/usr/bin/php

<?php

$var = 'three';

echo 'one two ' . $var;

?>
