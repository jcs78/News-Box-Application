create table articleCommentsTable(
	articleID	INT		NOT NULL	PRIMARY KEY,
	commentBy	VARCHAR(255),
	comment		VARCHAR(255)
);
