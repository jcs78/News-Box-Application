command to run back-up scripts

mysql -u USERNAME -p DATABASE < file.sql

Example:
sudo mysql -u root -p testDB2 <  userTable.sql
