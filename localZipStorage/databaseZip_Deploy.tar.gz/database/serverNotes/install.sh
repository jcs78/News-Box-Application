sudo apt install aptitude -y
sudo apt install git -y
sudo apt install php -y
sudo apt install php-amqp -y
sudo apt install rabbitmq-server -y
sudo apt install mysql-server -y

