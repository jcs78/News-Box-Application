sudo apt install aptitude
sudo apt install git
sudo apt install php
sudo apt install php-amqp
sudo apt install rabbitmq-server
sudo apt install mysql-server

