Notes:
Dec 2, 2020 ------------------------------------------
- if there is an incorrect login name/password the webpage should
	display that there is an error, but it currently does not.
	Check the main control for wsMainControl and index.php
