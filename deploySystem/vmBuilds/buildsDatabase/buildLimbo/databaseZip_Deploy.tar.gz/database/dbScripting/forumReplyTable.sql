CREATE TABLE forumReplyTable(
	forumID		INT		NOT NULL	PRIMARY KEY,
	replyBy		VARCHAR(255),
	reply		MEDIUMTEXT
);
