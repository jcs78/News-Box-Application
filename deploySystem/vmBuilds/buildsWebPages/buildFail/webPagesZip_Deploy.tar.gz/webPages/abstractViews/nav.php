<!-- This is NavBar -->

    <nav class="navbar">
      <div class="inner-width">
        <a href="#" class="logo"></a>
        <button class="menu-toggler">
          <span></span>
          <span></span>
          <span></span>
        </button>
        <!-- Where all the nav bar will list -->
        <div class="search-box">
          <input class="search-txt" type="text" name="" placeholder="Search" />
          <a class="search-btn" href="#">
            <i class="fas fa-search"></i>
          </a>
        </div>

        <div class="navbar-menu">

	  <a href="index.php?action=showLandingPage">Landing</a>

          <a href="index.php?action=showHome">Home</a>

	  <a href="index.php?action=showLogin">Login</a>

	  <a href="index.php?action=showRegister">Register</a>

          <a href="index.php?action=showForum">Forum</a>
        </div>
      </div>
    </nav>
