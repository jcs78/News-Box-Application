Oct 20, 2020------------------------------
- index.php is having problems displaying content to the screen
	it does not like the require statement at the top
- webServerSpeaker.php has php tags but they cause index.php
	to stall, probably causing an error
- when I did run for errors it said that you cannot start a
	session inside of the file, probably have to dig around
	to see how to fix this issue.

Oct 21, 2020------------------------------
- index.php is still not working, and shows the same error
